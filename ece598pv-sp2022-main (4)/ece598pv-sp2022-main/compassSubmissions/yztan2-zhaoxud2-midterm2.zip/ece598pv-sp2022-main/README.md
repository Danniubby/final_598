# Principles of Blockchains

Welcome! This is the repository for ECE 598 PV: Principles of Blockchains, Spring 2022 at University of Illinois, Urbana-Champaign. [Main website of the course](https://courses.grainger.illinois.edu/ece598pv/sp2022/).

## Discussion
We use Piazza for discussion.

## Project Suggestion
You need to run the project on your machines. **We strongly recommend Linux or Mac OS.**

## Warmup Project

- [Warmup 1](Warmup1). Due date: 12:30pm CT, Jan 25, 2022.
- [Warmup 2](Warmup2). Due date: 12:30pm CT, Feb 1, 2022.

## Midterm Project

- Team formation. Please form teams of 2 for this project. Due date: same as warmup 2.
- [Part 1](MidtermProject1). Due date: 12:30pm CT, Feb 8, 2022.
- [Part 2](MidtermProject2). Due date: 12:30pm CT, Feb 15, 2022.
- [Part 3](MidtermProject3). Due date: 12:30pm CT, Feb 22, 2022.
- [Part 4](MidtermProject4). (Will be released soon)
- [Part 5](MidtermProject5). (Will be released soon)
- [Part 6](MidtermProject6). (Will be released soon)
- 
## Policy
Submissions later than due date will get 0 points.