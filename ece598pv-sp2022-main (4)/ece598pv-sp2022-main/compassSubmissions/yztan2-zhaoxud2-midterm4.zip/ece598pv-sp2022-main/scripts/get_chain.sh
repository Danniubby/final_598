curl 127.0.0.1:7000/blockchain/longest-chain
echo "\n"
curl 127.0.0.1:7001/blockchain/longest-chain 
echo "\n"
curl 127.0.0.1:7002/blockchain/longest-chain
echo "\n"
